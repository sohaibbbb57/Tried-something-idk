# MyLocalAI

A modular, local-only AI assistant core.

## Requirements
- Python 3.10+
- A GGUF chat/instruct model
- `llama-cpp-python`

Put your model at `models/model.gguf`, or change `config/config.json`.

## Run
```bash
pip install -r requirements.txt
python main.py
```

## Commands
- `/help`
- `/clear`
- `/clear-all`
- `/learn key = value`
- `/forget key`
- `/memory`
- `/model`
- `/stats`
- `/save`
- `/exit`

The project stores conversations and learned facts locally. It does not call cloud APIs.
