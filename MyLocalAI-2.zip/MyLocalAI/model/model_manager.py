from __future__ import annotations
from model.loader import ModelLoader
from model.inference import Inference

class ModelManager:
    def __init__(self, settings):
        self.settings = settings
        self.loader = ModelLoader(settings)
        self.inference = None

    def load(self):
        model = self.loader.load()
        self.inference = Inference(model, self.settings)

    def stream(self, messages):
        if not self.inference:
            raise RuntimeError("Model is not loaded.")
        yield from self.inference.stream(messages)
