from __future__ import annotations
from pathlib import Path
from llama_cpp import Llama

class ModelLoader:
    def __init__(self, settings):
        self.settings = settings
        self.model = None

    def load(self):
        path = Path(self.settings.model_path)
        if not path.exists():
            raise FileNotFoundError(
                f"GGUF model not found: {path}. Put a model there or change config/config.json."
            )
        kwargs = dict(
            model_path=str(path),
            n_ctx=self.settings.n_ctx,
            n_threads=self.settings.n_threads,
            n_gpu_layers=self.settings.n_gpu_layers,
            verbose=False,
        )
        self.model = Llama(**kwargs)
        return self.model
