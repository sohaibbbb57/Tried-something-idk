from __future__ import annotations
class Inference:
    def __init__(self, model, settings):
        self.model = model; self.settings = settings

    def stream(self, messages):
        result = self.model.create_chat_completion(
            messages=messages,
            max_tokens=self.settings.max_tokens,
            temperature=self.settings.temperature,
            top_p=self.settings.top_p,
            top_k=self.settings.top_k,
            repeat_penalty=self.settings.repeat_penalty,
            stream=True,
        )
        for chunk in result:
            choices = chunk.get("choices", [])
            if choices:
                delta = choices[0].get("delta", {})
                text = delta.get("content", "")
                if text:
                    yield text

    def complete(self, messages):
        return "".join(self.stream(messages))
