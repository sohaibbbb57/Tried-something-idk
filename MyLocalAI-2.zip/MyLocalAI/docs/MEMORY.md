# Memory

`/learn key = value` stores a persistent fact.
`/forget key` removes one.
Chat messages are persisted separately in the same JSON database.
This is retrieval memory, not model fine-tuning.
