# Testing

From the project root:

```bash
python -m unittest discover -s tests
```

A real model test requires a GGUF model in `models/`.
