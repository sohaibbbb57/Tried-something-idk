# Architecture

`main.py` owns the CLI loop. `Brain` coordinates model, context, memory and local knowledge.
The model layer is isolated so the inference backend can be replaced later.
Memory is JSON-based for portability. Knowledge is local JSON retrieval.
The typing effect consumes streamed model chunks, so output appears incrementally.
