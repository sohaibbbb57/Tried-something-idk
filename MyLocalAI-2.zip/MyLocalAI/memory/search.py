from __future__ import annotations
import re

class MemorySearch:
    def search(self, query: str, messages: list[dict], limit=8):
        words = set(re.findall(r"\w+", query.lower()))
        scored = []
        for msg in messages:
            score = len(words & set(re.findall(r"\w+", msg["content"].lower())))
            if score:
                scored.append((score, msg))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [m for _,m in scored[:limit]]
