from __future__ import annotations
import json
from pathlib import Path
import re

class KnowledgeBase:
    """Loads all category JSON files from one local knowledge-base folder."""
    def __init__(self, directory="data/knowledge_base"):
        self.directory = Path(directory)
        self.items = []
        if not self.directory.exists():
            return
        for path in sorted(self.directory.glob("*.json")):
            if path.name == "MANIFEST.json":
                continue
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                category = data.get("category", path.stem)
                for entry in data.get("entries", []):
                    text = entry.get("fact", "")
                    if text:
                        self.items.append({
                            "category": category,
                            "id": entry.get("id"),
                            "text": text
                        })
            except (OSError, json.JSONDecodeError, TypeError):
                continue

    def search(self, query: str, limit=6):
        words = set(re.findall(r"\w+", query.lower()))
        scored = []
        for item in self.items:
            haystack = (item["category"] + " " + item["text"]).lower()
            score = sum(word in haystack for word in words)
            if score:
                scored.append((score, item))
        scored.sort(key=lambda pair: (-pair[0], pair[1]["category"], pair[1]["id"] or 0))
        return [item for _, item in scored[:limit]]
