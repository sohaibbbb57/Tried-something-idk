from datetime import datetime
class Session:
    def __init__(self):
        self.started_at = datetime.now().isoformat(timespec="seconds")
        self.turns = 0
    def turn(self):
        self.turns += 1
