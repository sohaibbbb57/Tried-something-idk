from __future__ import annotations
from utils.file_manager import read_json, write_json

class MemoryStore:
    def __init__(self, path="memory/database.json", max_messages=5000, max_facts=1000):
        self.path = path; self.max_messages = max_messages; self.max_facts = max_facts
        self.data = read_json(path, {"version":1,"facts":{},"messages":[],"metadata":{}})
        self.data.setdefault("facts", {}); self.data.setdefault("messages", [])

    def save(self):
        self.data["messages"] = self.data["messages"][-self.max_messages:]
        self.data["facts"] = dict(list(self.data["facts"].items())[-self.max_facts:])
        write_json(self.path, self.data)

    def add_message(self, role, content):
        self.data["messages"].append({"role": role, "content": content})
        self.save()

    def history(self):
        return list(self.data["messages"])

    def learn(self, key, value):
        self.data["facts"][key] = value; self.save()

    def forget(self, key):
        removed = self.data["facts"].pop(key, None) is not None
        self.save(); return removed

    def facts(self):
        return dict(self.data["facts"])

    def clear_messages(self):
        self.data["messages"] = []; self.save()

    def clear_all(self):
        self.data = {"version":1,"facts":{},"messages":[],"metadata":{}}
        self.save()
