import tempfile, json
from pathlib import Path
from memory.store import MemoryStore
from memory.knowledge import KnowledgeBase
from tools.tools import calculate, text_stats

def test_memory_roundtrip():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/"db.json"; m=MemoryStore(p, 10, 10)
        m.learn("name","Devran"); m.add_message("user","hello")
        n=MemoryStore(p, 10, 10)
        assert n.facts()["name"]=="Devran"
        assert n.history()[0]["content"]=="hello"

def test_clear_all():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/"db.json"; m=MemoryStore(p,10,10)
        m.learn("x","y"); m.add_message("user","z"); m.clear_all()
        assert not m.facts() and not m.history()

def test_safe_calculator():
    assert calculate("2 + 3 * 4") == 14
    assert text_stats("a b\nc")["words"] == 3

def test_knowledge():
    kb=KnowledgeBase("data/knowledge")
    assert kb.search("Python programming")
