from core.config import Settings
from utils.file_manager import read_text
from utils.logger import make_logger
from cli.console import command
from cli.typing_effect import print_stream
from core.brain import Brain

def main():
    settings=Settings.load()
    logger=make_logger()
    prompt=read_text("personality/system_prompt.txt", "You are a helpful local assistant.")
    brain=Brain(settings, logger)
    print("Loading local model...")
    brain.initialize(prompt)
    print("MyLocalAI ready. Type /help for commands.")
    while True:
        try: text=input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye."); break
        if not text: continue
        if text.startswith("/") and command(text, brain): break
        print("AI: ", end="", flush=True)
        print_stream(brain.reply_stream(text), settings.typing_delay)
if __name__=="__main__":
    main()
