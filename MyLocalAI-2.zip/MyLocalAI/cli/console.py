from cli.commands import parse_command

HELP = """Commands:
/help                 Show commands
/clear                Clear current and saved chat messages
/clear-all            Clear messages AND learned facts
/learn key = value    Save a persistent fact
/forget key           Remove a persistent fact
/memory               Show learned facts
/model                Show model configuration
/stats                Show session statistics
/save                 Save memory
/exit                 Quit
"""

def command(text, brain):
    cmd, args = parse_command(text)
    if not cmd: return False
    if cmd == "/help": print(HELP)
    elif cmd == "/clear": brain.memory.clear_messages(); print("Chat cleared.")
    elif cmd == "/clear-all": brain.memory.clear_all(); print("Chat and facts cleared.")
    elif cmd == "/learn":
        raw = " ".join(args)
        if "=" not in raw: print("Use: /learn key = value")
        else:
            k,v = [x.strip() for x in raw.split("=",1)]
            brain.memory.learn(k,v); print(f"Learned: {k}")
    elif cmd == "/forget":
        print("Forgot." if args and brain.memory.forget(args[0]) else "Nothing removed.")
    elif cmd == "/memory": print(brain.memory.facts() or "No learned facts.")
    elif cmd == "/model": print(brain.model_info())
    elif cmd == "/stats": print(brain.stats())
    elif cmd == "/save": brain.memory.save(); print("Saved.")
    elif cmd == "/exit": return True
    else: print("Unknown command. Use /help.")
    return False
