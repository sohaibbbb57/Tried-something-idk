def parse_command(text: str):
    if not text.startswith("/"): return None, []
    parts = text.split(maxsplit=1)
    return parts[0].lower(), parts[1:] if len(parts) > 1 else []
