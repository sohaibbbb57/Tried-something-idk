from __future__ import annotations
import sys, time

def print_stream(chunks, delay=0.012):
    full = []
    for chunk in chunks:
        full.append(chunk)
        for ch in chunk:
            print(ch, end="", flush=True)
            if delay > 0: time.sleep(delay)
    print()
    return "".join(full)
