from pathlib import Path
import ast
root=Path(__file__).resolve().parents[1]
errors=[]
for p in root.rglob("*.py"):
    try: ast.parse(p.read_text(encoding="utf-8"))
    except Exception as e: errors.append(f"{p}: {e}")
print("OK" if not errors else "\n".join(errors))
raise SystemExit(0 if not errors else 1)
