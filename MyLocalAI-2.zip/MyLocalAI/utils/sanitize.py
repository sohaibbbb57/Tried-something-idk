def clean_text(text: str) -> str:
    return " ".join(text.replace("\x00", "").split())

def safe_key(key: str) -> str:
    return key.strip().lower().replace(" ", "_")[:80]
