from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "config.json"
DB = ROOT / "memory" / "database.json"
MODEL_DIR = ROOT / "models"
KNOWLEDGE_DIR = ROOT / "data" / "knowledge"
LOG_DIR = ROOT / "data" / "logs"
