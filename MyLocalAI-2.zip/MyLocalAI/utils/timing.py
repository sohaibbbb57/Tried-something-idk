from __future__ import annotations
from contextlib import contextmanager
from time import perf_counter

@contextmanager
def timer():
    start = perf_counter()
    box = {}
    try:
        yield box
    finally:
        box["seconds"] = perf_counter() - start
