from __future__ import annotations
from core.context import ContextBuilder
from core.tokenizer import TokenCounter
from memory.store import MemoryStore
from memory.knowledge import KnowledgeBase
from memory.search import MemorySearch
from memory.session import Session
from model.model_manager import ModelManager
from tools.tool_manager import ToolManager

class Brain:
    def __init__(self, settings, logger):
        self.settings=settings; self.logger=logger
        self.memory=MemoryStore(max_messages=settings.memory["max_chat_messages"], max_facts=settings.memory["max_facts"])
        self.knowledge=KnowledgeBase()
        self.search=MemorySearch()
        self.session=Session()
        self.model=ModelManager(settings)
        self.context=ContextBuilder("", settings.history_messages)
        self.tokenizer=None
        self.prompt=""

    def initialize(self, prompt):
        self.prompt=prompt
        self.context=ContextBuilder(prompt, self.settings.history_messages)
        self.model.load()
        self.tokenizer=TokenCounter(self.model.loader.model)
        self.logger.info("Local model loaded.")

    def reply_stream(self, user_text):
        relevant=self.knowledge.search(user_text, self.settings.knowledge["max_results"]) if self.settings.knowledge["enabled"] else []
        messages=self.context.build_messages(self.memory.history(), self.memory.facts(), relevant)
        messages.append({"role":"user","content":user_text})
        # Keep the newest messages until the estimated context budget is acceptable.
        while len(messages) > 2 and self.tokenizer.count("\n".join(m["content"] for m in messages)) > self.settings.n_ctx - self.settings.max_tokens:
            messages.pop(1)
        self.memory.add_message("user", user_text)
        chunks=self.model.stream(messages)
        collected=[]
        for chunk in chunks:
            collected.append(chunk); yield chunk
        answer="".join(collected).strip()
        self.memory.add_message("assistant", answer)
        self.session.turn()

    def model_info(self):
        return {"model": self.settings.model_path, "context": self.settings.n_ctx, "gpu_layers": self.settings.n_gpu_layers}

    def stats(self):
        return {"turns": self.session.turns, "messages": len(self.memory.history()), "facts": len(self.memory.facts())}
