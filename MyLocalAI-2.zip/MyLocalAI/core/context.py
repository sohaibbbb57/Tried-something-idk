from __future__ import annotations
from typing import Iterable

class ContextBuilder:
    def __init__(self, system_prompt: str, max_messages: int = 40):
        self.system_prompt = system_prompt.strip()
        self.max_messages = max_messages

    def build_messages(self, history: Iterable[dict], facts: dict, knowledge: list[dict]) -> list[dict]:
        system = self.system_prompt
        if facts:
            system += "\n\nKnown user facts (use only when relevant):\n" + "\n".join(
                f"- {key}: {value}" for key, value in facts.items()
            )
        if knowledge:
            system += "\n\nRelevant local knowledge:\n" + "\n".join(
                f"- [{item['category']}] {item['text']}" for item in knowledge
            )
        messages = [{"role": "system", "content": system}]
        messages.extend(list(history)[-self.max_messages:])
        return messages
