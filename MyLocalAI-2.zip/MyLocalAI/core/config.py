from __future__ import annotations
from dataclasses import dataclass
from utils.file_manager import read_json

@dataclass
class Settings:
    model_path: str
    n_ctx: int
    n_threads: int
    n_gpu_layers: int
    max_tokens: int
    temperature: float
    top_p: float
    repeat_penalty: float
    top_k: int
    history_messages: int
    typing_delay: float
    stream_output: bool
    auto_save: bool
    memory: dict
    knowledge: dict
    tools: dict

    @classmethod
    def load(cls, path: str = "config/config.json"):
        return cls(**read_json(path, {}))
