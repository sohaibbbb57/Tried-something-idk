from __future__ import annotations
class TokenCounter:
    def __init__(self, model):
        self.model = model
    def count(self, text: str) -> int:
        try:
            return len(self.model.tokenize(text.encode("utf-8"), add_bos=False))
        except Exception:
            return max(1, len(text) // 4)
