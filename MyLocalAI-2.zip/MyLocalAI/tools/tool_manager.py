from tools.tools import calculate, text_stats

class ToolManager:
    def __init__(self, enabled=True):
        self.enabled = enabled
        self.tools = {"calculate": calculate, "text_stats": text_stats}

    def run(self, name, *args):
        if not self.enabled: raise RuntimeError("Tools are disabled.")
        if name not in self.tools: raise KeyError(f"Unknown tool: {name}")
        return self.tools[name](*args)

    def names(self):
        return sorted(self.tools)
