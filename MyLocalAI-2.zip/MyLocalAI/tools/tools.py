from __future__ import annotations
import ast, operator

OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
       ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
       ast.USub: operator.neg, ast.UAdd: operator.pos}

def calculate(expression: str):
    def ev(node):
        if isinstance(node, ast.Constant) and isinstance(node.value, (int,float)): return node.value
        if isinstance(node, ast.UnaryOp) and type(node.op) in OPS: return OPS[type(node.op)](ev(node.operand))
        if isinstance(node, ast.BinOp) and type(node.op) in OPS: return OPS[type(node.op)](ev(node.left), ev(node.right))
        raise ValueError("Unsupported expression")
    return ev(ast.parse(expression, mode="eval").body)

def text_stats(text: str):
    return {"characters": len(text), "words": len(text.split()), "lines": len(text.splitlines())}
